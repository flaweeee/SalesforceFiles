import { LightningElement } from 'lwc';

import searchCas from '@salesforce/apex/standardDataController.fetchCases';

const accCol = [{
    label:'Account Name',
    fieldName:'AccountURL',
    type:'url',
    typeAttributes:{
        label:{
            fieldName:'AccountName'
        }
    }
}, {
    label:'Phone',
    fieldName:"AccountPhone",
    type:"phone"
}, {
    label:"Industry",
    fieldName:"AccountIndustry",
    type:"text"
}, {
    label:"Type",
    fieldName: "AccountType",
    type:"text"
}

];

const conCol = [{
    label:'Contact Name',
    fieldName: 'ContactURL',
    type:'url',
    typeAttributes:{
        label:{
            fieldName:'ContactName'
        }
    }
}, {
    label:"Phone",
    fieldName:"ContactPhone",
    type:"phone"
}, {
    label:"Email",
    fieldName:"ContactEmail",
    type:"email"
}, {
    label:'Account Name',
    fieldName:'AccountURL',
    type:'url',
    typeAttributes:{
        label:{
            fieldName:'AccountName'
        }
    }
}

];

const casCol = [{
    label:'Cases Number',
    fieldName:'CaseURL',
    type:'url',
    typeAttributes:{
        label:{
            fieldName:'CaseNumber'
        }
    }
}, {
    label:'Subject',
    fieldName:'Subject',
    type:'text'
}, {
    label:'Account Name',
    fieldName:'AccountURL',
    type:'url',
    typeAttributes:{
        label:{
            fieldName:'AccountName'
        }
    }
}, {
    label:'Contact Name',
    fieldName: 'ContactURL',
    type:'url',
    typeAttributes:{
        label:{
            fieldName:'ContactName'
        }
    }
}

];

export default class HOTS extends LightningElement {  
    accountcolumn = accCol;
    contactcolumn = conCol;
    casecolumn = casCol;
    result;
    error;
 
    Search = '';

    keyHandler(e){
        this.Search = e.target.value;
        this.accountHandler();
        //console.log('this key press run' + this.Search);

    }

    accountHandler(){
        if (this.Search !== ''){
            searchCas({'Search':this.Search}).then( (res) => {
                if (res){
                    let finalChange=[];
                    res.forEach(row => {
                        let objectStruct = {};
                        objectStruct.Id = row.Id;
                        objectStruct.CaseNumber = row.CaseNumber;
                        objectStruct.Subject = row.Subject;
                        objectStruct.ContactName = row.Contact.Name;
                        objectStruct.AccountName = row.Account.Name;
                        objectStruct.AccountPhone = row.Account.Phone;
                        objectStruct.AccountIndustry = row.Account.Industry;
                        objectStruct.AccountType = row.Account.Type;
                        objectStruct.ContactPhone = row.Contact.Phone;
                        objectStruct.ContactEmail = row.Contact.Email;
                        objectStruct.Accountid = row.AccountId;
                        objectStruct.Contactid = row.ContactId;
                        objectStruct.AccountURL = 'https://carm3-dev-ed.lightning.force.com/lightning/r/Account/'+row.AccountId+'/view';
                        objectStruct.CaseURL = 'https://carm3-dev-ed.lightning.force.com/lightning/r/Case/'+row.Id+'/view';
                        objectStruct.ContactURL = 'https://carm3-dev-ed.lightning.force.com/lightning/r/Contact/'+row.ContactId+'/view'
                        finalChange.push(objectStruct);
                    });
                    this.result = finalChange;
                    //console.table(this.result);
                    //console.log('The result is: '+this.result);
                }
            }).catch(er => {
                this.error = er;
            })
        }
        
        else {
            this.result = null;
        }
    }
}