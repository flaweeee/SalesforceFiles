class JScriptdatasave {
    constructor (inputname, inputphonenumber, inputdateofbirth) {
    this.inputname = inputname;
    this.inputdateofbirth = new Date(inputdateofbirth);
    this.inputphonenumber = inputphonenumber;
    }

    generatePersonalID (){
        let perName = this.inputname.slice(0,4).toUpperCase();
        let perDate = this.inputdateofbirth.getDate().toString().padStart(2,0) + '' + 
            (this.inputdateofbirth.getMonth() + 1).toString().padStart(2,0) + '' + 
            this.inputdateofbirth.getFullYear().toString().slice(2);
        let perPhoneNumber = this.inputphonenumber.slice(5).toString();

        let stringResults = perName + perDate + perPhoneNumber;
        //console.log("This is the test result: " + stringResults);
        if (!isNaN(perPhoneNumber)){ //isNaN function returns TRUE if its not a number, so I inverse it to make it easy to understand..
            alert(`This is your PIN Code: ${stringResults}\n\nReminder: Save this first before clicking OK`);
        }
        else {
            alert("Phone Number must be a NUMBER");
        }
    }
}

//var testmethod = new JScriptdatasave("sddaa", "45454545455", "2015-06-11");
//var testmethod2 = testmethod.generatePersonalID();